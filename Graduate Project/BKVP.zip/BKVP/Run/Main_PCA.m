clc;
clear;
close all;
format shortG;

%% kNN Map
datasets ={'GLI_85', 'TOX_171', 'orlraws10P', 'dbworld_bodies',  'colon', 'SMK_CAN_187', 'lymphoma', 'nci9', 'DEX' };
                                 

% datasets = keys(datasetMethods);


% Initialize an empty cell array to store the summary of all datasets
OverallSummary = {'Dataset', 'BestRun', 'Time', 'BestAccuracy', 'MeanAccuracy', 'StdAccuracy', 'WorstAccuracy', 'BestFit', 'BestFeatIdx'};

%--------------------------------------------------------------------------------------------------------------

for d = 1:length(datasets)
    dataset_name = datasets{d};
    % method = datasetMethods(dataset_name);

    %% Notify which dataset is currently being processed
    disp(['Processing dataset: ' dataset_name]);

    %% Load dataset
    if strcmp(dataset_name, 'dbworld_bodies')
        % Parameters for DBE
    nRun = 30;                    % Number of runs
    nFilter = 500;                % Number of elite features to be filtered out
    popsize = 100;
    nfeat = 10;                   % Number of features in the final subset
    maxiter = 200;                % Number of iterations to evolve initial population
       % Load DBE dataset
        data = load(dataset_name);
        X_original = data.inputs;
        Y = data.labels;

    elseif strcmp(dataset_name, 'DEX')
        % Parameters for DBE
    nRun = 30;                    % Number of runs
    nFilter = 500;                % Number of elite features to be filtered out
    popsize = 100;
    nfeat = 10;                   % Number of features in the final subset
    maxiter = 200;                % Number of iterations to evolve initial population  
        % Load dataset for DEX
        X_pre = load_sparse_data('dexter_train.data');
        Y = load_labels('dexter_train.labels');
        num_samples_Y = size(Y, 1);
        X_aligned = X_pre(1:num_samples_Y, :);
        X_original = full(X_aligned);

    else
        % Parameters for all datasets excepts for DBE, DEX
    nRun = 30;                    % Number of runs
    nFilter = 100;                % Number of elite features to be filtered out
    popsize = 100;
    nfeat = 10;                   % Number of features in the final subset
    maxiter = 100;                % Number of iterations to evolve initial population
        % Load other datasets
        load(dataset_name);
        X_original = X;
    end

%----------------------------------------------------------------------------------------
%% Filter out elite features using PCA
[coeff, score, ~, ~, explained] = pca(X_original);
cumulative_explained = cumsum(explained);
num_pcs = find(cumulative_explained >= 95, 1);
coeff_selected = coeff(:, 1:num_pcs);
feature_contributions = sum(abs(coeff_selected), 2);
[~, feature_ranking] = sort(feature_contributions, 'descend');
selected_features = feature_ranking(1:nFilter);

X_filtered = X_original(:, selected_features);
[Mx, nvar] = size(X_filtered);
%----------------------------------------------------------------------------------------

%% Initialize mutual information parameters
MIxx = zeros(nvar, nvar);                      % Mutual information matrix between pairs of features
MIxy = zeros(1, nvar);                         % Mutual information matrix between features and target

%% Kernel matrices for MI calculation
mat.var = zeros(size(X_filtered, 1), size(X_filtered, 1));
Km = repmat(mat, size(X_filtered, 2), 1);
alpha = 0.1;
h = (Mx + 1) / sqrt(4) / Mx ^ (1 + alpha);
y = ctransform(Y');
h2 = 2 * h^2;
Ky = squareform(exp(-ssqd([y; y]) / h2)) + eye(Mx);

%% Initialize variables to store data for .mat file
Convergence_curveAllRuns = cell(nRun, 1);
Results = cell(nRun+1, 5);
Results(1, :) = {'Run', 'Time', 'Accuracy', 'BestFit', 'BestFeatIdx'};

for run = 1:nRun
    tic; % Start timer

    %% Apply heuristic algorithm
    Low = 1;
    Up = nFilter;
    memorySize = 50;

     [BestX, BestF, Convergence_curve] = BKFV(X_filtered, Y, nfeat, Low, Up, maxiter, popsize, MIxy, MIxx, Km, Ky, memorySize);

    disp([' Selected features are ' num2str(BestX)]);
    Reduced_dataset = X_filtered(:, BestX); % The reduced dataset (without target)
    Reduced_dataset = [Reduced_dataset, Y]; 

    %--------------------------------------------------------------------------------------------------------
    %% Perform LOOCV with CART (all datasets)
    model = fitctree(Reduced_dataset(:, 1:end-1), Reduced_dataset(:, end)); % Fit CART model
    CVModel = crossval(model, 'Leaveout', 'on'); % Perform LOOCV
    L = kfoldLoss(CVModel, 'LossFun', 'classiferror'); % Classification error
    Accuracy = 1 - L; % Accuracy
    %---------------------------------------------------------------------------------------------------------

    %% Record results
    Time = toc; % Stop timer
    BestFit = BestF;
    BestFeatIdx = BestX;
    Results{run+1, 1} = run;
    Results{run+1, 2} = Time;
    Results{run+1, 3} = Accuracy;
    Results{run+1, 4} = BestFit;
    Results{run+1, 5} = num2str(BestFeatIdx);
    disp ('----------------------------------------------------------------------------------------------------------------------------------')

    % Store data for .mat file
    Convergence_curveAllRuns{run} = Convergence_curve;
    
end

    %% Calculate and display summary statistics
    BestAccuracy = max(cell2mat(Results(2:end, 3)));
    MeanAccuracy = mean(cell2mat(Results(2:end, 3)));
    StdAccuracy = std(cell2mat(Results(2:end, 3)));
    WorstAccuracy = min(cell2mat(Results(2:end, 3)));
    
    % Find the best run
    [~, bestRunIdx] = max(cell2mat(Results(2:end, 3)));
    bestRunIdx = bestRunIdx + 1; % Adjust for the header row
    
    BestTime = Results{bestRunIdx, 2};
    BestFit = Results{bestRunIdx, 4};
    BestFeat = Results{bestRunIdx, 5};
    
    % Fill summary data
    Summary = {'BestRun', 'Time', 'BestAccuracy', 'MeanAccuracy', 'StdAccuracy', 'WorstAccuracy', 'BestFit', 'BestFeatIdx'; ...
               bestRunIdx-1, BestTime, BestAccuracy, MeanAccuracy, StdAccuracy, WorstAccuracy, BestFit, BestFeat};
    
    % Write summary to 'Summary' sheet
    filename = ['BKFV_PCA_CART_' dataset_name '.xlsx'];
    writecell(Results, filename, 'Sheet', 'Run');
    writecell(Summary, filename, 'Sheet', 'Summary');
    save(['BKFV_PCA_CART_' dataset_name '.mat'], 'Convergence_curveAllRuns');
    
    disp(['Summary has been saved to ' filename ' in the Summary sheet.']);
    disp('The entire process has been completed successfully.');

    %-----------------------------------------------------------------------------------------------------------
    %% Append summary data to the overall summary for all datasets
    OverallSummary(end+1, :) = {dataset_name, bestRunIdx-1, BestTime, BestAccuracy, MeanAccuracy, StdAccuracy, WorstAccuracy, BestFit, BestFeat};
end

%-----------------------------------------------------------------------------------------------------------
%% Save the overall summary for all datasets to a single Excel file
overallFilename = 'Overall_Summary.xlsx';
writecell(OverallSummary, overallFilename, 'Sheet', 'Summary');

disp(['Overall summary has been saved to ' overallFilename ' in the Summary sheet.']);
