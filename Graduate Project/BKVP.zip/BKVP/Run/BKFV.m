function [BestX, BestF, Convergence_curve] = BKFV(X, Y, nfeat, Low, Up, MaxIt, nPop, MIxy, MIxx, Km, Ky, memorySize)

    % Preallocate variables
    emp.var = [];
    emp.sel = [];
    emp.fit = [];
    pop = repmat(emp, nPop, 1);
    memoryBuffer = cell(memorySize, 1);
    bufferIndex = 1;
    
    % Initialize population
    for i = 1:nPop
        pop(i).var = randperm(size(X, 2)); 
        pop(i).sel = pop(i).var(1:nfeat); 
        [pop(i).fit, MIxy, MIxx, Km] = mRMR(X, Y, pop(i).sel, MIxy, MIxx, Km, Ky); 
        
        % Update memory buffer
        memoryBuffer{bufferIndex} = sort(pop(i).sel); 
        bufferIndex = mod(bufferIndex, memorySize) + 1;
    end
    
    % Sort the population based on fitness
    [~, sortedIndices] = sort([pop.fit]);
    
    % Find the initial best fitness and position
    gpop = pop(sortedIndices(1));  
    BestF = gpop.fit;
    BestX = gpop.sel;

    % Preallocate variables for new positions and fitness
    XPosNew = zeros(nPop, size(X, 2));
    XFit_New = zeros(nPop, 1);
    
    Convergence_curve = zeros(1, MaxIt);

    % Start iteration
    for t = 1:MaxIt
        % Attacking behavior
        n = 0.05 * exp(-2 * (t / MaxIt)^2);
        for i = 1:nPop
            r = rand;
            if r < 0.9
                % Adjusting size of XPosNew to match pop(i).sel
                XPosNew(i, 1:nfeat) = pop(i).sel + n .* (1 + sin(r)) .* pop(i).sel;
                XPosNew(i, 1:nfeat) = max(XPosNew(i, 1:nfeat), Low);
                XPosNew(i, 1:nfeat) = min(XPosNew(i, 1:nfeat), Up);
            else
                % Update XPosNew with the same number of features as pop(i).sel
                XPosNew(i, 1:nfeat) = pop(i).sel .* (n * (2 * rand(1, nfeat) - 1) + 1);
                XPosNew(i, 1:nfeat) = max(XPosNew(i, 1:nfeat), Low);
                XPosNew(i, 1:nfeat) = min(XPosNew(i, 1:nfeat), Up);
            end
        end
        
        % Migration behavior
        m = 2 * sin(rand + pi / 2);
        for i = 1:nPop
            s = randi([1, nPop], 1);
            r_XFitness = pop(s).fit;
            ori_value = rand(1, nfeat);
            cauchy_value = tan((ori_value - 0.5) * pi);
            if pop(i).fit < r_XFitness
                XPosNew(i, 1:nfeat) = pop(i).sel + cauchy_value .* (pop(i).sel - BestX);
            else
                XPosNew(i, 1:nfeat) = pop(i).sel + cauchy_value .* (BestX - m .* pop(i).sel);
            end
            XPosNew(i, 1:nfeat) = max(XPosNew(i, 1:nfeat), Low);
            XPosNew(i, 1:nfeat) = min(XPosNew(i, 1:nfeat), Up);
        end
        
        % Position Update strategy from FVIM
alpha = 1.5;  % Tuning parameter 

% Get the 1st, 2nd, 3rd, and 4th best positions
fstPos = pop(sortedIndices(1)).sel;  
sndPos = pop(sortedIndices(2)).sel;  
thrdPos = pop(sortedIndices(3)).sel;  
frthPos = pop(sortedIndices(4)).sel;  

alpha = alpha - 0.004;
for i = 1:nPop
    for j = 1:nfeat
        r3 = rand();
        X1 = updatePosition(fstPos(j), pop(i).sel(j), alpha, r3);
        r3 = rand();
        X2 = updatePosition(sndPos(j), pop(i).sel(j), alpha, r3);
        r3 = rand();
        X3 = updatePosition(thrdPos(j), pop(i).sel(j), alpha, r3);
        r3 = rand();
        X4 = updatePosition(frthPos(j), pop(i).sel(j), alpha, r3);
        pop(i).sel(j) = (X1 + X2 + X3 + X4) / 4;  % Updated position is now stored in pop(i).sel(j)
    end
end

% Update fitness values and apply memory buffer
for i = 1:nPop
    % Ensure that the updated positions respect the boundary constraints
    pop(i).sel = SpaceBound(pop(i).sel, Up, Low);
    
    % Recalculate fitness for the newly updated positions
    [XFit_New(i), MIxy, MIxx, Km] = mRMR(X, Y, pop(i).sel, MIxy, MIxx, Km, Ky);
    
    % If the new position improves fitness, update the population
    if XFit_New(i) < pop(i).fit
        pop(i).fit = XFit_New(i);  % Update fitness
        
        % Update memory buffer if the new position is not already stored
        if ~ismember(sort(pop(i).sel), cell2mat(memoryBuffer), 'rows')
            memoryBuffer{bufferIndex} = sort(pop(i).sel);
            bufferIndex = mod(bufferIndex, memorySize) + 1;
        end
    end
end

        
        % Update the optimal Black-winged Kite
        [~, sortedIndices] = sort([pop.fit]);  
        gpop = pop(sortedIndices(1));  
        if gpop.fit < BestF
            BestF = gpop.fit;
            BestX = gpop.sel;
        end
        Convergence_curve(t) = BestF;
        
        % Print out the process for tracking
        FEs = t * nPop;
        fprintf(1, 'Iterations = %d, FEs = %d\n', t, FEs);
        fprintf(1, 'Best fitness= %e\n\n', BestF);
    end
end

 function X = updatePosition(best, current, a, r3)
        if r3 < 0.5
            X = best + (a * 2 * rand() - a) * abs(rand() * best - current);
        else
            X = best - (a * 2 * rand() - a) * abs(rand() * best - current);  
        end 
end
