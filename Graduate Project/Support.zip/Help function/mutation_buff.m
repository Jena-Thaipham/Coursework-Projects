%% Modified mutation function
function [mutpop, MIxy, MIxx, Km, bufferIndex] = mutation_buff(mutpop, pop, nvar, X, Y, nmut, popsize, nfeat, MIxy, MIxx, Km, Ky, memoryBuffer, bufferIndex, memorySize)
    for i = 1:nmut
        idx = randi(popsize);
        mutpop(i).var = pop(idx).var;
        swap_idx = randperm(nvar, 2);
        temp = mutpop(i).var(swap_idx(1));
        mutpop(i).var(swap_idx(1)) = mutpop(i).var(swap_idx(2));
        mutpop(i).var(swap_idx(2)) = temp;
        mutpop(i).sel = mutpop(i).var(1:nfeat);
        [mutpop(i).fit, MIxy, MIxx, Km] = mRMR(X, Y, mutpop(i).sel, MIxy, MIxx, Km, Ky);
        
        % Ensure uniqueness with memory buffer
        isUnique = false;
        while ~isUnique
            isUnique = true;
            for j = 1:memorySize
                if isequal(sort(mutpop(i).sel), memoryBuffer{j})
                    isUnique = false;
                    swap_idx = randperm(nvar, 2);
                    temp = mutpop(i).var(swap_idx(1));
                    mutpop(i).var(swap_idx(1)) = mutpop(i).var(swap_idx(2));
                    mutpop(i).var(swap_idx(2)) = temp;
                    mutpop(i).sel = mutpop(i).var(1:nfeat);
                    [mutpop(i).fit, MIxy, MIxx, Km] = mRMR(X, Y, mutpop(i).sel, MIxy, MIxx, Km, Ky);
                    break;
                end
            end
        end
        
        % Update memory buffer
        memoryBuffer{bufferIndex} = sort(mutpop(i).sel);
        bufferIndex = mod(bufferIndex, memorySize) + 1;
    end
end
