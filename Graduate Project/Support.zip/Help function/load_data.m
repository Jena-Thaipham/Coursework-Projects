% Load and inspect each file
files = {'dbworld_bodies.mat', 'dbworld_bodies_stemmed.mat', 'dbworld_subjects.mat', 'dbworld_subjects_stemmed.mat'};

for i = 1:length(files)
    % Load the data
    data = load(files{i});
    
    % Display field names and sizes
    disp(['File: ' files{i}]);
    disp('Field names and sizes:');
    fields = fieldnames(data);
    for j = 1:length(fields)
        disp([fields{j} ': ' num2str(size(data.(fields{j})))]);
    end
    disp(' ');
end
