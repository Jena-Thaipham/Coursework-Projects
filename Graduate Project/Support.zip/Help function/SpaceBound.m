
function newSel = SpaceBound(newSel, Up, Low)
    newSel = max(min(newSel, Up), Low);
    newSel = round(newSel); 
end