
function ranks = mutual_info_ranking(X, Y)
    % Number of features
    numFeatures = size(X, 2);
    
    % Calculate mutual information for each feature with the target
    mi = zeros(1, numFeatures);
    for i = 1:numFeatures
        mi(i) = mutual_information(X(:, i), Y);
    end
    
    % Rank features by mutual information
    [~, ranks] = sort(mi, 'descend');
end