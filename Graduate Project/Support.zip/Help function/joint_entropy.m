
function h = joint_entropy(x, y)
    % Calculate the joint entropy of two variables
    p = histcounts2(x, y, 'Normalization', 'probability');
    p(p == 0) = []; % Remove zero probabilities
    h = -sum(p(:) .* log2(p(:)));
end