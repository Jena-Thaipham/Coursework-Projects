
% Function to load sparse data from a file
function X = load_sparse_data(filename)
    fid = fopen(filename, 'r');
    data = textscan(fid, '%f:%f');
    fclose(fid);
    
    feature_indices = data{1};
    feature_values = data{2};
    
    num_features = max(feature_indices);
    num_samples = length(unique(feature_indices));
    
    X = sparse(num_samples, num_features);
    
    current_sample = 1;
    for i = 1:length(feature_indices)
        if feature_indices(i) == 1
            current_sample = current_sample + 1;
        end
        X(current_sample, feature_indices(i)) = feature_values(i);
    end
end