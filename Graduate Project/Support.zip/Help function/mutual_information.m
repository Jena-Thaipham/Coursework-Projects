function mi = mutual_information(x, y)
    % Calculate mutual information between two variables
    hx = entropy(x);
    hy = entropy(y);
    hxy = joint_entropy(x, y);
    mi = hx + hy - hxy;
end