
function h = entropy(x)
    % Calculate the entropy of a variable
    p = histcounts(x, 'Normalization', 'probability');
    p(p == 0) = []; % Remove zero probabilities
    h = -sum(p .* log2(p));
end