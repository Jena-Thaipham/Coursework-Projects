
% Function to load labels from a file
function Y = load_labels(filename)
    Y = dlmread(filename);
end