function [bstVal, fstPos, sndPos, thrdPos, frthPos, convCurve, traj, fitHist, posHist] = FVBKGA(X, Y, nfeat, lb, ub, maxIter, pNum, MIxy, MIxx, Km, Ky, memorySize)

    % Initialize memory buffer
    memoryBuffer = cell(memorySize, 1);
    bufferIndex = 1;

    % Initialize population
    emp.var = [];
    emp.sel = [];
    emp.fit = [];
    pop = repmat(emp, pNum, 1);

    % Initialize positions and fitness values
    fstPos = zeros(1, nfeat);
    fstVal = inf;
    sndPos = zeros(1, nfeat);
    sndVal = inf;
    thrdPos = zeros(1, nfeat);
    thrdVal = inf;
    frthPos = zeros(1, nfeat);
    frthVal = inf;
    bstVal = inf;

    alpha = 1.5;

    % Assign stored variables for plotting
    deltaPos1 = zeros(1, maxIter);
    fitHist = zeros(pNum, maxIter);
    posHist = zeros(pNum, maxIter, nfeat);
    traj = zeros(pNum, maxIter);

    % Initialize particle positions and fitness
    for i = 1:pNum
               
        pop(i).var = randperm(size(X, 2)); % Random permutation of feature indices
        pop(i).sel = pop(i).var(1:nfeat); % Select first nfeat features

        % Calculate fitness using mRMR
        [pop(i).fit, MIxy, MIxx, Km] = mRMR(X, Y, pop(i).sel, MIxy, MIxx, Km, Ky);
        
        % Update memory buffer
        memoryBuffer{bufferIndex} = sort(pop(i).sel); % Store selected features in memory buffer
        bufferIndex = mod(bufferIndex, memorySize) + 1;
    end

    % Initialize positions and fitness values for particles
    convCurve = zeros(1, maxIter);
    iter = 0;

    % Main loop
    while iter <= maxIter
        iter = iter + 1;
        for i = 1:pNum
            % Handle boundary conditions
            ubFlag = pop(i).sel > ub;
            lbFlag = pop(i).sel < lb;
            pop(i).sel = pop(i).sel .* ~(ubFlag + lbFlag) + ub .* ubFlag + lb .* lbFlag;

            % Evaluate fitness
            pop(i).sel = SpaceBound(pop(i).sel, ub, lb);
            [fit, MIxy, MIxx, Km] = mRMR(X, Y, pop(i).sel, MIxy, MIxx, Km, Ky);
            updateSolutionHierarchy(fit, pop(i).sel);
            
            % Store fitness and positions
            pop(i).fit = fit;
            fitHist(i, iter) = fit;
            posHist(i, iter, :) = pop(i).sel;
            traj(i, iter) = pop(i).sel(1);
        end

%% GA mutation part 
        % GA parameters
        if (nfeat == 1)
            pm = 1;
        else
            pm = 0.02;
        end
        nmut = round(pNum * pm * nfeat); % Number of mutate chromosomes

        
        mutpop = repmat(emp, nmut, 1);
        [mutpop, MIxy, MIxx, Km, bufferIndex] = mutation_buff(mutpop, pop, size(X, 2), X, Y, nmut, pNum, nfeat, MIxy, MIxx, Km, Ky, memoryBuffer, bufferIndex, memorySize);

        pop = [pop; mutpop];
        [~, index] = sort([pop.fit]);
        gpop = pop(1);
        pop = pop(1:pNum);
        bstVal = gpop.fit;
        fstPos = gpop.sel;

% Migration behavior from BKA
        m = 2 * sin(rand + pi / 2);
        XPosNew = zeros(pNum, nfeat); % Initialize new positions
        for i = 1:pNum
            s = randi([1, pNum], 1);
            r_XFitness = pop(s).fit;
            ori_value = rand(1, nfeat);
            cauchy_value = tan((ori_value - 0.5) * pi);
            if pop(i).fit < r_XFitness
                XPosNew(i, 1:nfeat) = pop(i).sel + cauchy_value .* (pop(i).sel - fstPos);
            else
                XPosNew(i, 1:nfeat) = pop(i).sel + cauchy_value .* (fstPos - m .* pop(i).sel);
            end
            XPosNew(i, 1:nfeat) = max(XPosNew(i, 1:nfeat), lb);
            XPosNew(i, 1:nfeat) = min(XPosNew(i, 1:nfeat), ub);
        end
        
        % Update fitness values and apply memory buffer
        for i = 1:pNum
            XPosNew(i, 1:nfeat) = SpaceBound(XPosNew(i, 1:nfeat), ub, lb);
            [XFit_New, MIxy, MIxx, Km] = mRMR(X, Y, XPosNew(i, 1:nfeat), MIxy, MIxx, Km, Ky);
            updateSolutionHierarchy(XFit_New, XPosNew(i, 1:nfeat));
                
                % Update memory buffer
                if ~ismember(sort(XPosNew(i, 1:nfeat)), cell2mat(memoryBuffer), 'rows')
                    memoryBuffer{bufferIndex} = sort(XPosNew(i, 1:nfeat));
                    bufferIndex = mod(bufferIndex, memorySize) + 1;
                end

        % Store fitness and positions
            pop(i).fit = XFit_New;
            fitHist(i, iter) = XFit_New;
            posHist(i, iter, :) = XPosNew(i, 1:nfeat);
            traj(i, iter) = XPosNew(1);
         end

        % Update positions using FVIM
        alpha = alpha - 0.004;
        for i = 1:pNum
            for j = 1:nfeat
                r3 = rand();
                X1 = updatePosition(fstPos(j), pop(i).sel(j), alpha, r3);
                r3 = rand();
                X2 = updatePosition(sndPos(j), pop(i).sel(j), alpha, r3);
                r3 = rand();
                X3 = updatePosition(thrdPos(j), pop(i).sel(j), alpha, r3);
                r3 = rand();
                X4 = updatePosition(frthPos(j), pop(i).sel(j), alpha, r3);
                pop(i).sel(j) = (X1 + X2 + X3 + X4) / 4;
            end
        end
        
        % Update the optimal solution
        updateBestValue();
        convCurve(iter) = bstVal;

        % Update memory buffer
        memoryBuffer{bufferIndex} = sort(fstPos); % Store selected features in memory buffer
        bufferIndex = mod(bufferIndex, memorySize) + 1;

        % Calculate the number of function evaluations
        FEs = iter * pNum;

        % Print out the process for tracking
        fprintf(1, 'Iterations = %d, FEs = %d\n', iter, FEs);
        fprintf(1, 'Best fitness = %e\n\n', bstVal);
    end

    %% Helper functions
    function updateSolutionHierarchy(fitness, position)
        if fitness < fstVal
            [frthVal, thrdVal, sndVal, fstVal] = deal(thrdVal, sndVal, fstVal, fitness);
            [frthPos, thrdPos, sndPos, fstPos] = deal(thrdPos, sndPos, fstPos, position);
        elseif fitness < sndVal
            [frthVal, thrdVal, sndVal] = deal(thrdVal, sndVal, fitness);
            [frthPos, thrdPos, sndPos] = deal(thrdPos, sndPos, position);
        elseif fitness < thrdVal
            [frthVal, thrdVal] = deal(thrdVal, fitness);
            [frthPos, thrdPos] = deal(thrdPos, position);
        elseif fitness < frthVal
            frthVal = fitness;
            frthPos = position;
        end
    end

    function X = updatePosition(best, current, a, r3)
        if r3 < 0.5
            X = best + (a * 2 * rand() - a) * abs(rand() * best - current);
        else
            X = best - (a * 2 * rand() - a) * abs(rand() * best - current);  
        end 
    end

    function updateBestValue()
        bstVal = min([fstVal, sndVal, thrdVal, frthVal]);  
    end

end
