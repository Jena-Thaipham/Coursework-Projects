clc;
clear;
close all;
format shortG;

%% Parameters for all datasets excepts for DBE, DEX
nRun = 2;                    % Number of runs
nFilter = 100;                % Number of elite features to be filtered out
popsize = 100;
nfeat = 10;                   % Number of features in the final subset
maxiter = 4;                % Number of iterations to evolve initial population

%% Load datasets
datasets = {'colon'};  

for d = 1:length(datasets)
    dataset_name = datasets{d};
    load(dataset_name);
    X_original = X;

%----------------------------------------------------------------------------------------
%% Feature reduction using Chi-square feature selection
    [idx, scores] = fscchi2(X_original, Y);
    [~, sorted_idx] = sort(scores, 'descend');
    selected_features = sorted_idx(1:nFilter);
    X_filtered = X_original(:, selected_features);

    [Mx, nvar] = size(X_filtered);   
%----------------------------------------------------------------------------------------

%% Initialize mutual information parameters
MIxx = zeros(nvar, nvar);                      % Mutual information matrix between pairs of features
MIxy = zeros(1, nvar);                         % Mutual information matrix between features and target

%% Kernel matrices for MI calculation
mat.var = zeros(size(X_filtered, 1), size(X_filtered, 1));
Km = repmat(mat, size(X_filtered, 2), 1);
alpha = 0.1;
h = (Mx + 1) / sqrt(4) / Mx ^ (1 + alpha);
y = ctransform(Y');
h2 = 2 * h^2;
Ky = squareform(exp(-ssqd([y; y]) / h2)) + eye(Mx);

%% Initialize variables to store data for .mat file
Convergence_curveAllRuns = cell(nRun, 1);
Results = cell(nRun+1, 5);
Results(1, :) = {'Run', 'Time', 'Accuracy', 'BestFit', 'BestFeatIdx'};

for run = 1:nRun
    tic; % Start timer

    %% Apply heuristic algorithm
    Low = 1;
    Up = nFilter;
    memorySize = 50;

    [BestF, BestX, sndPos, thrdPos, frthPos, Convergence_curve, traj, fitHist, posHist] = FVBKGA(X_filtered, Y, nfeat, Low, Up, maxiter, popsize, MIxy, MIxx, Km, Ky, memorySize);

    disp([' Selected features are ' num2str(BestX)]);
    Reduced_dataset = X_filtered(:, BestX); % The reduced dataset (without target)
    Reduced_dataset = [Reduced_dataset, Y]; 

    %--------------------------------------------------------------------------------------------------------
    %% Perform a binary class SVM with LOOCV using fitcsvm
    model = fitcsvm(Reduced_dataset(:, 1:end-1), Reduced_dataset(:, end), 'KernelFunction', 'linear');
    CVModel = crossval(model, 'KFold', length(Reduced_dataset)); % LOOCV
    L = kfoldLoss(CVModel);
    Accuracy = 1 - L;
    %---------------------------------------------------------------------------------------------------------

    %% Record results
    Time = toc; % Stop timer
    BestFit = BestF;
    % BestFeat = X_filtered(:, BestX);
    BestFeatIdx = BestX;
    Results{run+1, 1} = run;
    Results{run+1, 2} = Time;
    Results{run+1, 3} = Accuracy;
    Results{run+1, 4} = BestFit;
    Results{run+1, 5} = num2str(BestFeatIdx);
    
    % disp([' Run = ' num2str(run) ' Time = ' num2str(Time) ' Accuracy = ' num2str(Accuracy) ' BestFit = ' num2str(BestFit)]);
    % disp('Best Features:');
    % disp(BestFeat);
    disp ('----------------------------------------------------------------------------------------------------------------------------------')

     % Store data for .mat file
        Convergence_curveAllRuns{run} = Convergence_curve;
        
        % Save results to Excel file
        filename = ['FVBKGA_ChiSq_SVM_' dataset_name '.xlsx'];
        
        % Write run details to 'Run' sheet
        writecell(Results, filename, 'Sheet', 'Run');
        
        % Save all runs data to a .mat file
        save(['FVBKGA_ChiSq_SVM_' dataset_name '.mat'], 'Convergence_curveAllRuns');
        
    end
    
    %% Calculate and display summary statistics
    BestAccuracy = max(cell2mat(Results(2:end, 3)));
    MeanAccuracy = mean(cell2mat(Results(2:end, 3)));
    StdAccuracy = std(cell2mat(Results(2:end, 3)));
    WorstAccuracy = min(cell2mat(Results(2:end, 3)));
    
    % Find the best run
    [~, bestRunIdx] = max(cell2mat(Results(2:end, 3)));
    bestRunIdx = bestRunIdx + 1; % Adjust for the header row
    
    BestTime = Results{bestRunIdx, 2};
    BestFit = Results{bestRunIdx, 4};
    BestFeat = Results{bestRunIdx, 5};
    
    % Fill summary data
    Summary = {'BestRun', 'Time', 'BestAccuracy', 'MeanAccuracy', 'StdAccuracy', 'WorstAccuracy', 'BestFit', 'BestFeatIdx'; ...
               bestRunIdx-1, BestTime, BestAccuracy, MeanAccuracy, StdAccuracy, WorstAccuracy, BestFit, BestFeat};
    
    % Write summary to 'Summary' sheet
    writecell(Summary, filename, 'Sheet', 'Summary');
    disp(['Summary has been saved to ' filename ' in the Summary sheet.']);
    disp('The entire process has been completed successfully.');
end